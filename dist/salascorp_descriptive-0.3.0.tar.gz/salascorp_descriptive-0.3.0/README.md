# salascorp_descriptive
simplifies descriptive analysis before building propensity models. It offers key features like descriptive stats, distribution tests, interactive visualizations, and variable transformations. Ideal for streamlining data prep and gaining insights before launching predictive models.
